package com.example.rejestrator;

public class Ryba {
    public String id;
    public String nazwa;
    public String opis;
    public String przyneta;
    public String zaneta;

    public Ryba(String id, String nazwa, String opis, String przyneta, String zaneta) {
        this.id = id;
        this.nazwa = nazwa;
        this.opis = opis;
        this.przyneta = przyneta;
        this.zaneta = zaneta;
    }



}