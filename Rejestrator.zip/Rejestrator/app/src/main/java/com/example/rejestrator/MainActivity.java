package com.example.rejestrator;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.LinearLayout;


import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.drawerlayout.widget.DrawerLayout;

import com.google.android.material.navigation.NavigationView;
import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;

import org.osmdroid.config.Configuration;
import org.osmdroid.events.MapEventsReceiver;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.MapEventsOverlay;
import org.osmdroid.views.overlay.Marker;

import java.lang.reflect.Type;
import java.util.ArrayList;
import java.util.Map;
import java.util.ArrayList;
import java.util.List;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.ListView;
import android.widget.EditText;
import android.widget.LinearLayout;


import com.google.gson.Gson;
import com.google.gson.reflect.TypeToken;
import java.lang.reflect.Type;
import androidx.appcompat.widget.Toolbar;
import androidx.appcompat.app.ActionBarDrawerToggle;
import androidx.drawerlayout.widget.DrawerLayout;
import com.google.android.material.navigation.NavigationView;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;
import android.widget.ImageButton;

public class MainActivity extends AppCompatActivity {

    private MapView map;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // WAŻNE: Konfiguracja osmdroid (musi być przed setContentView)
        Context ctx = getApplicationContext();
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx));

        setContentView(R.layout.activity_main);

        map = findViewById(R.id.map);
        map.setMultiTouchControls(true); // Przybliżanie palcami

        // Ustaw startową pozycję (np. środek Polski)
        map.getController().setZoom(6.0);
        map.getController().setCenter(new GeoPoint(52.23, 21.01));

        prefs = getSharedPreferences("RybyPamiatke", MODE_PRIVATE);

        // Wczytaj zapisane punkty
        wczytajPunkty();

        // Obsługa kliknięć na mapie
        MapEventsReceiver mReceive = new MapEventsReceiver() {
            @Override
            public boolean singleTapConfirmedHelper(GeoPoint p) { return false; }

            @Override
            public boolean longPressHelper(GeoPoint p) {
                pokazDialog(p);
                return true;
            }

        };
        // Wewnątrz onCreate dopisz:
        wczytajAtlas();
        odswiezListe();
        // 1. Znajdź Toolbar i ustaw go jako pasek akcji
        Toolbar toolbar = findViewById(R.id.toolbar);
        setSupportActionBar(toolbar);

// 2. Znajdź DrawerLayout
        DrawerLayout drawer = findViewById(R.id.drawer_layout);

// 3. To tworzy animację "trzech kresek"
        ActionBarDrawerToggle toggle = new ActionBarDrawerToggle(
                this, drawer, toolbar, R.string.open, R.string.close);
        drawer.addDrawerListener(toggle);
        toggle.syncState();

// 4. Obsługa kliknięć w menu (Mapa / Atlas)
        NavigationView navView = findViewById(R.id.nav_view);
        navView.setNavigationItemSelectedListener(item -> {
            int id = item.getItemId();
            if (id == R.id.nav_mapa) {
                findViewById(R.id.map_container).setVisibility(View.VISIBLE);
                findViewById(R.id.atlas_container).setVisibility(View.GONE);
            } else if (id == R.id.nav_album) {
                findViewById(R.id.map_container).setVisibility(View.GONE);
                findViewById(R.id.atlas_container).setVisibility(View.VISIBLE);
                odswiezListe(); // Ważne, żeby lista się załadowała!
            }
            drawer.closeDrawers();
            return true;
        });
        // 1. Znajdź ten plusik z pliku layout_atlas.xml
        com.google.android.material.floatingactionbutton.FloatingActionButton btnDodaj = findViewById(R.id.dodaj_rybe_btn);

// 2. Nadaj mu "słuch" na kliknięcia
        if (btnDodaj != null) {
            btnDodaj.setOnClickListener(v -> {
                // Wywołujemy metodę, którą pisałeś wcześniej
                pokazFormularzRyby(null);
            });
        }


        map.getOverlays().add(new MapEventsOverlay(mReceive));
    }

    private void pokazDialog(GeoPoint p) {
        // Tworzymy kontener, żeby zmieścić dwa pola tekstowe
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 20, 50, 20);

        final EditText inputNazwa = new EditText(this);
        inputNazwa.setHint("Nazwa miejscówki");
        layout.addView(inputNazwa);

        final EditText inputRyby = new EditText(this);
        inputRyby.setHint("Co tu bierze?");
        layout.addView(inputRyby);

        new AlertDialog.Builder(this)
                .setTitle("Dodaj nową miejscówkę")
                .setView(layout)
                .setPositiveButton("Zapisz", (d, w) -> {
                    String nazwa = inputNazwa.getText().toString();
                    String ryby = inputRyby.getText().toString();

                    // Łączymy dane do zapisu: Nazwa|Ryby
                    String infoDoZapisu = nazwa + "|" + ryby;
                    String klucz = p.getLatitude() + "," + p.getLongitude();

                    prefs.edit().putString(klucz, infoDoZapisu).apply();

                    dodajMarker(p, nazwa, ryby);
                })
                .setNegativeButton("Anuluj", null)
                .show();
    }

    private void dodajMarker(GeoPoint p, String tytul, String opis) {
        Marker m = new Marker(map);
        m.setPosition(p);
        m.setTitle(tytul);
        m.setSubDescription(opis);
        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);

        // Reagujemy na długie kliknięcie w samą pinezkę
        m.setOnMarkerClickListener(new Marker.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker, MapView mapView) {
                // Po krótkim kliknięciu - po prostu pokaż dymek (to zostawiamy)
                marker.showInfoWindow();

                // ALE od razu zapytajmy, czy użytkownik chce coś zrobić
                // Możemy tu dodać opcję usuwania w prostym menu:
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle(tytul)
                        .setMessage("Co chcesz zrobić z tą miejscówką?")
                        .setPositiveButton("Usuń", (dialog, which) -> {
                            // Usuwanie z mapy
                            map.getOverlays().remove(marker);
                            map.invalidate();

                            // Usuwanie z pamięci
                            String klucz = p.getLatitude() + "," + p.getLongitude();
                            prefs.edit().remove(klucz).apply();
                        })
                        .setNegativeButton("Nic", (dialog, which) -> dialog.dismiss())
                        .show();

                return true;
            }
        });

        map.getOverlays().add(m);
        map.invalidate();
    }

    private void wczytajPunkty() {
        // Upewnij się, że pobierasz klucz "punkty_mapy", a NIE "atlas_json"!
        String dane = prefs.getString("punkty_mapy", "");
        if (!dane.isEmpty()) {
            String[] punkty = dane.split(";");
            for (String p : punkty) {
                try {
                    String[] wspolrzedne = p.split(",");
                    double lat = Double.parseDouble(wspolrzedne[0]);
                    double lon = Double.parseDouble(wspolrzedne[1]);
                    // Zamiast dodajMarker(new GeoPoint(lat, lon)); wpisz:
                    dodajMarker(new GeoPoint(lat, lon), "Tytuł ryby", "Opis ryby");
                } catch (Exception e) {
                    // Ignoruj błędne punkty
                }
            }
        }
    }
    private List<Ryba> atlasRyb = new ArrayList<>();
    private ArrayAdapter<Ryba> adapter;

    private void pokazFormularzRyby(Ryba edytowanaRyba) {
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(40, 20, 40, 20);

        final EditText n = new EditText(this); n.setHint("Nazwa ryby"); layout.addView(n);
        final EditText o = new EditText(this); o.setHint("Opis"); layout.addView(o);
        final EditText p = new EditText(this); p.setHint("Przynęta"); layout.addView(p);
        final EditText z = new EditText(this); z.setHint("Zanęta"); layout.addView(z);

        if(edytowanaRyba != null) {
            n.setText(edytowanaRyba.nazwa); o.setText(edytowanaRyba.opis);
            p.setText(edytowanaRyba.przyneta); z.setText(edytowanaRyba.zaneta);
        }

        new AlertDialog.Builder(this)
                .setTitle(edytowanaRyba == null ? "Dodaj rybę do Atlasu" : "Edytuj rybę")
                .setView(layout)
                .setPositiveButton("Zapisz", (d, w) -> {
                    if(edytowanaRyba != null) atlasRyb.remove(edytowanaRyba);
                    atlasRyb.add(new Ryba(String.valueOf(System.currentTimeMillis()),
                            n.getText().toString(), o.getText().toString(),
                            p.getText().toString(), z.getText().toString()));
                    zapiszAtlas();
                    odswiezListe();
                })
                .show();
    }

    private void zapiszAtlas() {
        String json = new Gson().toJson(atlasRyb);
        prefs.edit().putString("atlas_json", json).apply();
    }

    private void wczytajAtlas() {
        String json = prefs.getString("atlas_json", "[]");
        Type type = new TypeToken<ArrayList<Ryba>>(){}.getType();
        atlasRyb = new Gson().fromJson(json, type);
    }
    private void odswiezListe() {
        ListView listView = findViewById(R.id.lista_ryb);
        if (listView == null) return;

        // Tworzymy nasz własny adapter
        RybaAdapter customAdapter = new RybaAdapter();
        listView.setAdapter(customAdapter);
    }
    private class RybaAdapter extends ArrayAdapter<Ryba> {
        public RybaAdapter() {
            super(MainActivity.this, R.layout.item_ryba, atlasRyb);
        }

        @Override
        public View getView(int position, View convertView, ViewGroup parent) {
            if (convertView == null) {
                convertView = getLayoutInflater().inflate(R.layout.item_ryba, parent, false);
            }

            Ryba r = getItem(position);
            TextView txtNazwa = convertView.findViewById(R.id.text_nazwa_ryby);
            ImageButton btnEdit = convertView.findViewById(R.id.btn_edit);
            ImageButton btnDelete = convertView.findViewById(R.id.btn_delete);

            txtNazwa.setText(r.nazwa);

            // Kliknięcie w nazwę -> Rozwijane info (szczegóły)
            convertView.setOnClickListener(v -> {
                new AlertDialog.Builder(getContext())
                        .setTitle(r.nazwa)
                        .setMessage("Opis: " + r.opis + "\nPrzynęta: " + r.przyneta + "\nZanęta: " + r.zaneta)
                        .setPositiveButton("OK", null)
                        .show();
            });

            // Przycisk Edycji
            btnEdit.setOnClickListener(v -> pokazFormularzRyby(r));

            // Przycisk Usuwania
            btnDelete.setOnClickListener(v -> {
                new AlertDialog.Builder(getContext())
                        .setTitle("Usuwanie")
                        .setMessage("Czy na pewno chcesz usunąć rybę: " + r.nazwa + "?")
                        .setPositiveButton("Tak", (d, w) -> {
                            atlasRyb.remove(position);
                            zapiszAtlas();
                            notifyDataSetChanged();
                        })
                        .setNegativeButton("Nie", null)
                        .show();
            });

            return convertView;
        }
    }
}