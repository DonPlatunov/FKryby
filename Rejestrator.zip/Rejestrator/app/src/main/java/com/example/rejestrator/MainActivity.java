package com.example.rejestrator;

import android.content.Context;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.preference.PreferenceManager;
import android.widget.EditText;
import android.widget.LinearLayout;

import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;

import org.osmdroid.config.Configuration;
import org.osmdroid.events.MapEventsReceiver;
import org.osmdroid.util.GeoPoint;
import org.osmdroid.views.MapView;
import org.osmdroid.views.overlay.MapEventsOverlay;
import org.osmdroid.views.overlay.Marker;

import java.util.Map;

public class MainActivity extends AppCompatActivity {

    private MapView map;
    private SharedPreferences prefs;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // WAŻNE: Konfiguracja osmdroid (musi być przed setContentView)
        Context ctx = getApplicationContext();
        Configuration.getInstance().load(ctx, PreferenceManager.getDefaultSharedPreferences(ctx));

        setContentView(R.layout.activity_main);

        map = findViewById(R.id.map);
        map.setMultiTouchControls(true); // Przybliżanie palcami

        // Ustaw startową pozycję (np. środek Polski)
        map.getController().setZoom(6.0);
        map.getController().setCenter(new GeoPoint(52.23, 21.01));

        prefs = getSharedPreferences("RybyPamiatke", MODE_PRIVATE);

        // Wczytaj zapisane punkty
        wczytajPunkty();

        // Obsługa kliknięć na mapie
        MapEventsReceiver mReceive = new MapEventsReceiver() {
            @Override
            public boolean singleTapConfirmedHelper(GeoPoint p) { return false; }

            @Override
            public boolean longPressHelper(GeoPoint p) {
                pokazDialog(p);
                return true;
            }
        };

        map.getOverlays().add(new MapEventsOverlay(mReceive));
    }

    private void pokazDialog(GeoPoint p) {
        // Tworzymy kontener, żeby zmieścić dwa pola tekstowe
        LinearLayout layout = new LinearLayout(this);
        layout.setOrientation(LinearLayout.VERTICAL);
        layout.setPadding(50, 20, 50, 20);

        final EditText inputNazwa = new EditText(this);
        inputNazwa.setHint("Nazwa miejscówki");
        layout.addView(inputNazwa);

        final EditText inputRyby = new EditText(this);
        inputRyby.setHint("Co tu bierze?");
        layout.addView(inputRyby);

        new AlertDialog.Builder(this)
                .setTitle("Dodaj nową miejscówkę")
                .setView(layout)
                .setPositiveButton("Zapisz", (d, w) -> {
                    String nazwa = inputNazwa.getText().toString();
                    String ryby = inputRyby.getText().toString();

                    // Łączymy dane do zapisu: Nazwa|Ryby
                    String infoDoZapisu = nazwa + "|" + ryby;
                    String klucz = p.getLatitude() + "," + p.getLongitude();

                    prefs.edit().putString(klucz, infoDoZapisu).apply();

                    dodajMarker(p, nazwa, ryby);
                })
                .setNegativeButton("Anuluj", null)
                .show();
    }

    private void dodajMarker(GeoPoint p, String tytul, String opis) {
        Marker m = new Marker(map);
        m.setPosition(p);
        m.setTitle(tytul);
        m.setSubDescription(opis);
        m.setAnchor(Marker.ANCHOR_CENTER, Marker.ANCHOR_BOTTOM);

        // Reagujemy na długie kliknięcie w samą pinezkę
        m.setOnMarkerClickListener(new Marker.OnMarkerClickListener() {
            @Override
            public boolean onMarkerClick(Marker marker, MapView mapView) {
                // Po krótkim kliknięciu - po prostu pokaż dymek (to zostawiamy)
                marker.showInfoWindow();

                // ALE od razu zapytajmy, czy użytkownik chce coś zrobić
                // Możemy tu dodać opcję usuwania w prostym menu:
                new AlertDialog.Builder(MainActivity.this)
                        .setTitle(tytul)
                        .setMessage("Co chcesz zrobić z tą miejscówką?")
                        .setPositiveButton("Usuń", (dialog, which) -> {
                            // Usuwanie z mapy
                            map.getOverlays().remove(marker);
                            map.invalidate();

                            // Usuwanie z pamięci
                            String klucz = p.getLatitude() + "," + p.getLongitude();
                            prefs.edit().remove(klucz).apply();
                        })
                        .setNegativeButton("Nic", (dialog, which) -> dialog.dismiss())
                        .show();

                return true;
            }
        });

        map.getOverlays().add(m);
        map.invalidate();
    }

    private void wczytajPunkty() {
        Map<String, ?> dane = prefs.getAll();
        for (Map.Entry<String, ?> entry : dane.entrySet()) {
            String[] c = entry.getKey().split(",");
            GeoPoint p = new GeoPoint(Double.parseDouble(c[0]), Double.parseDouble(c[1]));

            // Rozdzielamy zapisaną nazwę od opisu ryb
            String wartosc = entry.getValue().toString();
            if (wartosc.contains("|")) {
                String[] czesci = wartosc.split("\\|");
                dodajMarker(p, czesci[0], czesci[1]);
            } else {
                dodajMarker(p, "Miejscówka", wartosc); // Dla starych wpisów
            }
        }
    }
}